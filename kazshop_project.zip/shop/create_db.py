import sqlite3
import csv
import hashlib
import os

DB_PATH = "shop.db"

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def create_database():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Таблица пользователей
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            email TEXT
        )
    """)

    # Таблица товаров
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id TEXT,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            price REAL NOT NULL,
            discount INTEGER DEFAULT 0,
            final_price REAL NOT NULL,
            image_url TEXT DEFAULT ''
        )
    """)

    # Таблица истории просмотров
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (product_id) REFERENCES products(id)
        )
    """)

    # Таблица покупок
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            purchased_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (product_id) REFERENCES products(id)
        )
    """)

    conn.commit()

    # Добавляем тестовых пользователей (если их нет)
    test_users = [
        ("admin", "admin123", "admin@shop.kz"),
        ("user1", "password1", "user1@shop.kz"),
        ("test", "test123", "test@shop.kz"),
    ]
    for username, password, email in test_users:
        cursor.execute(
            "INSERT OR IGNORE INTO users (username, password, email) VALUES (?, ?, ?)",
            (username, hash_password(password), email)
        )

    conn.commit()

    # Загружаем товары из CSV
    csv_file = "ecommerce_dataset_updated.csv"
    if os.path.exists(csv_file):
        # Категории с красивыми именами
        category_names = {
            "Electronics": [
                "Samsung Galaxy A54", "Apple AirPods Pro", "Xiaomi Redmi Watch",
                "Logitech MX Keys", "Sony WH-1000XM5", "JBL Flip 6",
                "Anker PowerBank 20000", "TP-Link Router", "Philips Monitor 27\"",
                "Kingston SSD 512GB"
            ],
            "Clothing": [
                "Мужская куртка Nike", "Женское платье Zara", "Джинсы Levi's 501",
                "Кроссовки Adidas", "Толстовка Puma", "Рубашка Calvin Klein",
                "Пальто женское", "Мужской костюм", "Спортивный костюм",
                "Зимние ботинки"
            ],
            "Sports": [
                "Гантели 10кг набор", "Коврик для йоги", "Велосипед горный",
                "Скакалка боксёрская", "Мяч футбольный Adidas", "Ракетка для тенниса",
                "Кроссовки беговые", "Перчатки для зала", "Штанга 50кг",
                "Велотренажёр"
            ],
            "Beauty": [
                "Крем для лица Nivea", "Шампунь Head&Shoulders", "Духи Chanel",
                "Тушь для ресниц", "Помада Mac", "Сыворотка для лица",
                "Набор кистей для макияжа", "Тональный крем", "Маска для волос",
                "Гель для душа"
            ],
            "Toys": [
                "LEGO City набор", "Кукла Barbie", "Машинка на радиоуправлении",
                "Пазл 1000 деталей", "Настольная игра Монополия", "Конструктор 200 деталей",
                "Мягкая игрушка медведь", "Детский планшет", "Набор для рисования",
                "Велосипед детский"
            ],
            "Books": [
                "Python для начинающих", "Гарри Поттер (набор)", "Атомные привычки",
                "Мастер и Маргарита", "Думай и богатей", "1984 Джордж Оруэлл",
                "Чистый код Роберт Мартин", "Богатый папа бедный папа",
                "Sapiens Юваль Харари", "Искусство войны"
            ],
            "Home & Kitchen": [
                "Мультиварка Redmond", "Кофемашина DeLonghi", "Блендер Philips",
                "Сковорода с антипригаром", "Набор посуды 6 предметов",
                "Пылесос Dyson", "Утюг Bosch", "Чайник электрический",
                "Микроволновая печь", "Холодильник мини"
            ],
        }

        # Читаем CSV и импортируем уникальные товары по категориям
        existing = cursor.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        if existing == 0:
            with open(csv_file, newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                added_products = {cat: 0 for cat in category_names}
                row_num = 0
                for row in reader:
                    cat = row["Category"]
                    if cat in category_names:
                        idx = added_products[cat]
                        if idx < len(category_names[cat]):
                            name = category_names[cat][idx]
                            price = float(row["Price (Rs.)"])
                            discount = int(row["Discount (%)"])
                            final_price = float(row["Final_Price(Rs.)"])
                            cursor.execute(
                                """INSERT INTO products (product_id, name, category, price, discount, final_price)
                                   VALUES (?, ?, ?, ?, ?, ?)""",
                                (row["Product_ID"], name, cat, price, discount, final_price)
                            )
                            added_products[cat] += 1

        conn.commit()
        total = cursor.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        print(f"✅ Товаров в базе: {total}")
    else:
        print("⚠️  CSV файл не найден, товары не загружены")

    # Добавляем тестовую историю для user1
    user1 = cursor.execute("SELECT id FROM users WHERE username='user1'").fetchone()
    if user1:
        uid = user1[0]
        # Берём несколько товаров для истории
        products = cursor.execute("SELECT id FROM products LIMIT 5").fetchall()
        for (pid,) in products:
            cursor.execute(
                "INSERT OR IGNORE INTO history (user_id, product_id) VALUES (?, ?)",
                (uid, pid)
            )
    conn.commit()
    conn.close()
    print("✅ База данных создана успешно!")
    print("✅ Тестовые пользователи: admin/admin123, user1/password1, test/test123")

if __name__ == "__main__":
    create_database()
