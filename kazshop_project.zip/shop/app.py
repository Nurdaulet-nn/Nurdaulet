from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import sqlite3
import hashlib
import math
from collections import defaultdict

app = Flask(__name__)
app.secret_key = "kaspi_shop_secret_key_2024"  # Секретный ключ для сессий

DB_PATH = "shop.db"

# ─────────────────────────────────────────────
#  УТИЛИТЫ
# ─────────────────────────────────────────────

def get_db():
    """Открываем соединение с БД"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Чтобы получать данные как словарь
    return conn

def hash_password(password):
    """Хешируем пароль"""
    return hashlib.sha256(password.encode()).hexdigest()

def login_required(f):
    """Декоратор: проверяем, что пользователь вошёл"""
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

# ─────────────────────────────────────────────
#  СИСТЕМА РЕКОМЕНДАЦИЙ (как в Kaspi)
# ─────────────────────────────────────────────

def get_simple_recommendations(category, product_id=None, limit=8):
    """Простые рекомендации: по той же категории"""
    conn = get_db()
    if product_id:
        rows = conn.execute(
            "SELECT * FROM products WHERE category=? AND id!=? ORDER BY RANDOM() LIMIT ?",
            (category, product_id, limit)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM products WHERE category=? ORDER BY RANDOM() LIMIT ?",
            (category, limit)
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_smart_recommendations(user_id, limit=8):
    """
    Умные рекомендации (content-based filtering + история):
    1. Смотрим, что пользователь просматривал
    2. Считаем, какие категории он смотрел чаще всего
    3. Рекомендуем товары из этих категорий, которые он ещё не видел
    4. Сортируем по "весу" категории (cosine similarity упрощённо)
    """
    conn = get_db()

    # Получаем историю просмотров пользователя
    history = conn.execute("""
        SELECT p.category, p.id as product_id
        FROM history h
        JOIN products p ON h.product_id = p.id
        WHERE h.user_id = ?
        ORDER BY h.viewed_at DESC
        LIMIT 50
    """, (user_id,)).fetchall()

    viewed_product_ids = set(row["product_id"] for row in history)

    if not history:
        # Если истории нет — показываем популярные (случайные)
        rows = conn.execute(
            "SELECT * FROM products ORDER BY RANDOM() LIMIT ?", (limit,)
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows], "popular"

    # Считаем вес каждой категории (сколько раз смотрел)
    category_weights = defaultdict(int)
    for i, row in enumerate(history):
        # Последние просмотры важнее (убывающий вес)
        weight = 1.0 / (i + 1)
        category_weights[row["category"]] += weight

    # Нормализуем веса (cosine similarity упрощённо)
    total = sum(category_weights.values())
    for cat in category_weights:
        category_weights[cat] /= total

    # Строим список рекомендаций: товары из нужных категорий, которые ещё не смотрел
    recommendations = []
    for category, weight in sorted(category_weights.items(), key=lambda x: -x[1]):
        # Сколько товаров берём из этой категории (пропорционально весу)
        n = max(1, round(weight * limit * 1.5))
        rows = conn.execute("""
            SELECT * FROM products
            WHERE category = ?
            AND id NOT IN ({})
            ORDER BY RANDOM()
            LIMIT ?
        """.format(",".join("?" * len(viewed_product_ids)) if viewed_product_ids else "0"),
            (category, *viewed_product_ids, n) if viewed_product_ids else (category, n)
        ).fetchall()
        recommendations.extend([dict(r) for r in rows])

    conn.close()

    # Убираем дубликаты и ограничиваем
    seen = set()
    unique = []
    for item in recommendations:
        if item["id"] not in seen:
            seen.add(item["id"])
            unique.append(item)
        if len(unique) >= limit:
            break

    return unique, "smart"

def record_view(user_id, product_id):
    """Записываем просмотр товара в историю"""
    conn = get_db()
    conn.execute(
        "INSERT INTO history (user_id, product_id) VALUES (?, ?)",
        (user_id, product_id)
    )
    conn.commit()
    conn.close()

# ─────────────────────────────────────────────
#  РОУТЫ (страницы)
# ─────────────────────────────────────────────

@app.route("/")
def index():
    """Главная страница"""
    conn = get_db()

    # Категории для фильтрации
    categories = conn.execute(
        "SELECT DISTINCT category FROM products ORDER BY category"
    ).fetchall()

    # Выбранная категория из URL (?category=Electronics)
    selected_cat = request.args.get("category", "")
    search_query = request.args.get("search", "").strip()

    # Строим запрос безопасно (защита от SQL-инъекций через параметры)
    if search_query and selected_cat:
        products = conn.execute(
            "SELECT * FROM products WHERE category=? AND name LIKE ? ORDER BY id",
            (selected_cat, f"%{search_query}%")
        ).fetchall()
    elif search_query:
        products = conn.execute(
            "SELECT * FROM products WHERE name LIKE ? ORDER BY id",
            (f"%{search_query}%",)
        ).fetchall()
    elif selected_cat:
        products = conn.execute(
            "SELECT * FROM products WHERE category=? ORDER BY id",
            (selected_cat,)
        ).fetchall()
    else:
        products = conn.execute(
            "SELECT * FROM products ORDER BY id"
        ).fetchall()

    conn.close()

    # Рекомендации для главной страницы
    recommendations = []
    if "user_id" in session:
        recs, _ = get_smart_recommendations(session["user_id"], limit=4)
        recommendations = recs

    return render_template(
        "index.html",
        products=[dict(p) for p in products],
        categories=[dict(c) for c in categories],
        selected_cat=selected_cat,
        search_query=search_query,
        recommendations=recommendations,
        username=session.get("username")
    )

@app.route("/product/<int:product_id>")
def product_detail(product_id):
    """Страница товара"""
    conn = get_db()
    product = conn.execute(
        "SELECT * FROM products WHERE id=?", (product_id,)
    ).fetchone()
    conn.close()

    if not product:
        return "Товар не найден", 404

    product = dict(product)

    # Записываем просмотр (если пользователь вошёл)
    if "user_id" in session:
        record_view(session["user_id"], product_id)

    # Похожие товары
    similar = get_simple_recommendations(product["category"], product_id, limit=4)

    return render_template(
        "product.html",
        product=product,
        similar=similar,
        username=session.get("username")
    )

@app.route("/recommend")
@login_required
def recommend():
    """Простые рекомендации по категории"""
    conn = get_db()
    categories = conn.execute(
        "SELECT DISTINCT category FROM products ORDER BY category"
    ).fetchall()
    conn.close()

    selected_cat = request.args.get("category", "Electronics")
    recs = get_simple_recommendations(selected_cat, limit=8)

    return render_template(
        "recommend.html",
        recommendations=recs,
        categories=[dict(c) for c in categories],
        selected_cat=selected_cat,
        username=session.get("username"),
        mode="simple"
    )

@app.route("/recommend/smart")
@login_required
def recommend_smart():
    """Умные рекомендации (как в Kaspi)"""
    user_id = session["user_id"]
    recs, mode = get_smart_recommendations(user_id, limit=8)

    # История пользователя для отображения
    conn = get_db()
    history = conn.execute("""
        SELECT p.name, p.category, h.viewed_at
        FROM history h
        JOIN products p ON h.product_id = p.id
        WHERE h.user_id = ?
        ORDER BY h.viewed_at DESC
        LIMIT 5
    """, (user_id,)).fetchall()
    conn.close()

    return render_template(
        "recommend_smart.html",
        recommendations=recs,
        history=[dict(h) for h in history],
        mode=mode,
        username=session.get("username")
    )

@app.route("/login", methods=["GET", "POST"])
def login():
    """Страница входа"""
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        # Защита от пустых полей
        if not username or not password:
            error = "Введите логин и пароль"
        else:
            conn = get_db()
            user = conn.execute(
                "SELECT * FROM users WHERE username=? AND password=?",
                (username, hash_password(password))
            ).fetchone()
            conn.close()

            if user:
                session["user_id"] = user["id"]
                session["username"] = user["username"]
                return redirect(url_for("index"))
            else:
                error = "Неверный логин или пароль"

    return render_template("login.html", error=error)

@app.route("/register", methods=["GET", "POST"])
def register():
    """Страница регистрации"""
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        email = request.form.get("email", "").strip()

        if not username or not password:
            error = "Заполните все поля"
        elif len(password) < 6:
            error = "Пароль должен быть минимум 6 символов"
        else:
            conn = get_db()
            # Проверяем, что такого пользователя нет
            existing = conn.execute(
                "SELECT id FROM users WHERE username=?", (username,)
            ).fetchone()

            if existing:
                error = "Такой пользователь уже существует"
                conn.close()
            else:
                conn.execute(
                    "INSERT INTO users (username, password, email) VALUES (?, ?, ?)",
                    (username, hash_password(password), email)
                )
                conn.commit()
                # Автовход после регистрации
                user = conn.execute(
                    "SELECT * FROM users WHERE username=?", (username,)
                ).fetchone()
                conn.close()
                session["user_id"] = user["id"]
                session["username"] = user["username"]
                return redirect(url_for("index"))

    return render_template("register.html", error=error)

@app.route("/logout")
def logout():
    """Выход"""
    session.clear()
    return redirect(url_for("index"))

@app.route("/api/recommendations")
def api_recommendations():
    """API для рекомендаций (JSON)"""
    if "user_id" not in session:
        return jsonify({"error": "Нужно войти"}), 401
    recs, mode = get_smart_recommendations(session["user_id"], limit=6)
    return jsonify({"recommendations": recs, "mode": mode})

# ─────────────────────────────────────────────
#  ЗАПУСК
# ─────────────────────────────────────────────

if __name__ == "__main__":
    import os
    if not os.path.exists(DB_PATH):
        print("⚙️  База данных не найдена, запустите create_db.py сначала!")
    app.run(debug=True)
